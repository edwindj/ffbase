.onLoad <- function(lib, pkg) {
	#library.dynam("ffbase", pkg, lib )
}
