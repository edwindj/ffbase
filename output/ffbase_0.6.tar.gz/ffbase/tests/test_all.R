#library(ffbase)
#
#if (require(testthat)){
#   print("testing...")
#   test_package("ffbase")
#}
